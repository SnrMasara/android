package com.example.masara.firstaidguide;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Masara on 4/12/2018.
 */

public class Medical_Conditions extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.medical_conditions);

        listView=findViewById(R.id.ListViewMedicalConditions);
        String[] Values= new String[]{
                "Allergic reaction and second dose\n" +
                        "of epinephrine for anaphylaxis",
                "Poisoning",
                "Breathing difficulties",
                "Chest pain",
                "Stroke",
                "Dehydration and gastrointestinal\n" +
                        "distress",
                "Seizures",
                "Fever",
                "Diabetes and hypoglycaemia\n" +
                        "treatment",
                "Use of oxygen",
                "Shock and optimal position\n" +
                        "for shock",
                "Unresponsive and altered\n" +
                        "mental status",
                "Fainting",
                "Croup",
        };
        ArrayAdapter<String> ArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_list_item_2,
                android.R.id.text2, Values);

        listView.setAdapter(ArrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                if (position==0)
                {
                    Intent myintent =new Intent(view.getContext(), Allergy.class);
                    startActivity(myintent);
                }
                if (position==1)
                {
                    Intent myintent =new Intent(view.getContext(), Poisoning.class);
                    startActivity(myintent);
                }

                if (position==2)
            {
                Intent myintent =new Intent(view.getContext(), Breathing.class);
                startActivity(myintent);
            }
                if (position==3)
                {
                    Intent myintent =new Intent(view.getContext(), Chest_Pain.class);
                    startActivity(myintent);
                }
                if (position==4)
                {
                    Intent myintent =new Intent(view.getContext(), Stroke.class);
                    startActivity(myintent);
                }
                if (position==5)
                {
                    Intent myintent =new Intent(view.getContext(), Dehydration.class);
                    startActivity(myintent);
                }
                if (position==6)
                {
                    Intent myintent =new Intent(view.getContext(), Seizures.class);
                    startActivity(myintent);
                }
                if (position==7)
                {
                    Intent myintent =new Intent(view.getContext(), Fever.class);
                    startActivity(myintent);
                }
                if (position==8)
                {
                    Intent myintent =new Intent(view.getContext(), Diabetes.class);
                    startActivity(myintent);
                }
                if (position==9)
                {
                    Intent myintent =new Intent(view.getContext(), Oxygen.class);
                    startActivity(myintent);
                }
                if (position==10)
                {
                    Intent myintent =new Intent(view.getContext(), Shock.class);
                    startActivity(myintent);
                }
                if (position==11)
                {
                    Intent myintent =new Intent(view.getContext(), Unresponsive.class);
                    startActivity(myintent);
                }
                if (position==12)
                {
                    Intent myintent =new Intent(view.getContext(), Fainting.class);
                    startActivity(myintent);
                }
                if (position==13)
                {
                    Intent myintent =new Intent(view.getContext(), Croup.class);
                    startActivity(myintent);
                }




            }
        });


    }
}
