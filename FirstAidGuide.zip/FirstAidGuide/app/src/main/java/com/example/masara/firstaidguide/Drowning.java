package com.example.masara.firstaidguide;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Masara on 6/11/2018.
 */

public class Drowning extends AppCompatActivity {
    ListView listView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drowning_main);

        listView=findViewById(R.id.listview_drowning);
        String [] Values= new String[]
                {
                        "Drowning Process",
                        "Cervical spine injury among drowning casualties",
                        "Scuba diving decompression illness",

                };
        ArrayAdapter <String> arrayAdapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1, android.R.id.text1, Values);
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                if (position==0)
                {
                    Intent myintent =new Intent(view.getContext(),DrowningOverview.class);
                    startActivity(myintent);
                }
                if (position==1)
                {
                    Intent myintent =new Intent(view.getContext(),drowningSpineInjury.class);
                    startActivity(myintent);
                }
                if (position==2)
                {
                    Intent myintent =new Intent(view.getContext(),ScubaIllness.class);
                    startActivity(myintent);
                }


            }
        });



    }
}
