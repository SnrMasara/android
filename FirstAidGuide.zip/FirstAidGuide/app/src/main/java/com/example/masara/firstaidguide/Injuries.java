package com.example.masara.firstaidguide;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Masara on 4/23/2018.
 */

public class Injuries extends AppCompatActivity{

    ListView listView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.injuries);
    listView=findViewById(R.id.ListViewInjuries);
    String [] Values= new String[]
            {

                   "Foreign body airway obstruction" ,
                    "Burns",
                    "Bleeding",
                    "Amputation",
                    "Concussion",
                    "Cervical spinal motion restriction",
                    "Chest and abdomen injuries",
                    "Extremity injuries",
                    "Wounds and abrasions",
                    "Dental avulsion",
                    "Injuries due to chemical exposure",
    };
        ArrayAdapter <String> Adapter=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_2,
                android.R.id.text2, Values);
        listView.setAdapter(Adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                if (position==0)
                {
                    Intent myintent =new Intent(view.getContext(), Obstruction.class);
                    startActivity(myintent);
                }
                if (position==1)
                {
                    Intent myintent =new Intent(view.getContext(), Burns.class);
                    startActivity(myintent);
                }
                if (position==2)
                {
                    Intent myintent =new Intent(view.getContext(), Bleeding.class);
                    startActivity(myintent);
                }
                if (position==3)
                {
                    Intent myintent =new Intent(view.getContext(), Amputation.class);
                    startActivity(myintent);
                }
                if (position==4)
                {
                    Intent myintent =new Intent(view.getContext(), Concussion.class);
                    startActivity(myintent);
                }
                if (position==5)
                {
                    Intent myintent =new Intent(view.getContext(), Restriction.class);
                    startActivity(myintent);
                }
                if (position==6)
                {
                    Intent myintent =new Intent(view.getContext(), Chest_Injury.class);
                    startActivity(myintent);
                }
                if (position==7)
                {
                    Intent myintent =new Intent(view.getContext(), Extremity.class);
                    startActivity(myintent);
                }
                if (position==8)
                {
                    Intent myintent =new Intent(view.getContext(), Wounds.class);
                    startActivity(myintent);
                }
                if (position==9)
                {
                    Intent myintent =new Intent(view.getContext(), Dental.class);
                    startActivity(myintent);
                }
                if (position==10)
                {
                    Intent myintent =new Intent(view.getContext(), Chemical_Injury.class);
                    startActivity(myintent);
                }



            }
        });
    }
}
