package com.example.masara.firstaidguide;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Masara on 4/12/2018.
 */

public class MainActivity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView=findViewById(R.id.ListViewMain);
        String[] Values= new String[]{
                "First aid for medical conditions",
                "First aid for injuries",
                "Environmental health problems",
                "First aid for animal-related impairments",
                "Drowning and scuba diving decompression illness",
                "Resuscitation",
                "Psychological first aid"
        };
        ArrayAdapter<String> Adapter=new ArrayAdapter<String>
                (this,android.R.layout.simple_list_item_1, android.R.id.text1, Values);
        listView.setAdapter(Adapter);
    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

            if (position==0)
            {
                Intent myintent =new Intent(view.getContext(), Medical_Conditions.class);
                startActivity(myintent);
            }
            if (position==1)
            {
                Intent myintent =new Intent(view.getContext(), Injuries.class);
                startActivity(myintent);
            }

            if (position==2)
            {
                Intent myintent =new Intent(view.getContext(), EnvironmentalProblems.class);
                startActivity(myintent);
            }
            if (position==3)
            {
                Intent myintent =new Intent(view.getContext(), Animal_Imparements.class);
                startActivity(myintent);
            }
            if (position==4)
            {
                Intent myintent =new Intent(view.getContext(), Drowning.class);
                startActivity(myintent);
            }
        }
    });

    }
}
