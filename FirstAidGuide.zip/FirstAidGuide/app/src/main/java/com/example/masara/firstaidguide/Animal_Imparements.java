package com.example.masara.firstaidguide;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Masara on 5/4/2018.
 */

public class Animal_Imparements extends AppCompatActivity {

    ListView listView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.animal_imparements);

        listView=findViewById(R.id.ListViewAnimal_imparements);


        String [] Values= new String[]
                {
                        "Animal bites",
                        "Snakebites",
                        "Jellyfish stings",
                        "Insect bites or stings",
                };
        ArrayAdapter <String> ArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,
                android.R.id.text1, Values);
        listView.setAdapter(ArrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                if (position==0)
                {
                    Intent myintent =new Intent(view.getContext(),AnimalBites.class);
                    startActivity(myintent);
                }
                if (position==1)
                {
                    Intent myintent =new Intent(view.getContext(),SnakeBites.class);
                    startActivity(myintent);
                }
                if (position==2)
                {
                    Intent myintent =new Intent(view.getContext(),jellyfish.class);
                    startActivity(myintent);
                }
                if (position==3)
                {
                    Intent myintent =new Intent(view.getContext(),InsectSting.class);
                    startActivity(myintent);
                }


            }
        });


    }
}
