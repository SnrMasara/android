package com.example.masara.firstaidguide;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Masara on 5/2/2018.
 */

public class EnvironmentalProblems extends AppCompatActivity {
    ListView listView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.environmental_problems);


        listView=findViewById(R.id.EnvironmentalProbListView);
        String [] Values= new String[]
                {
                        "Health problems caused by cold",
                        "Health problems caused by high altitude",
                        "Radiation emergencies",
                };
        ArrayAdapter <String> ArrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_list_item_2,
                android.R.id.text2, Values);
        listView.setAdapter(ArrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {


                if (position==0)
                {
                    Intent myintent =new Intent(view.getContext(),cold.class);
                    startActivity(myintent);
                }

                if (position==1)
                {
                    Intent myintent =new Intent(view.getContext(),altitude.class);
                    startActivity(myintent);
                }
                if (position==2)
                {
                    Intent myintent =new Intent(view.getContext(),Radiation.class);
                    startActivity(myintent);
                }

            }
        });

    }
}

